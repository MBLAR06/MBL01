# MoonlightBL - Plataforma de Catálogo BL/LGBT

## Descripción
Plataforma de catálogo y visualización de series BL, miniseries, películas y anime LGBT con panel de administración completo.

## Stack Tecnológico
- **Backend**: FastAPI (Python)
- **Frontend**: React + TailwindCSS + Shadcn/UI
- **Base de datos**: MongoDB

## Requisitos Previos
- Python 3.9+
- Node.js 18+
- MongoDB

## Instalación

### 1. Backend
```bash
cd backend
pip install -r requirements.txt
```

Configurar variables de entorno en `backend/.env`:
```
MONGO_URL="mongodb://localhost:27017"
DB_NAME="moonlightbl"
JWT_SECRET="tu_clave_secreta_aqui"
CORS_ORIGINS="*"
```

Iniciar el servidor:
```bash
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### 2. Frontend
```bash
cd frontend
yarn install  # o npm install
```

Configurar variables de entorno en `frontend/.env`:
```
REACT_APP_BACKEND_URL=http://localhost:8001
```

Iniciar el servidor de desarrollo:
```bash
yarn start  # o npm start
```

## Credenciales de Administrador
- **Usuario**: ADMINBL
- **Contraseña**: 86@$#&bihutrfcñpKGe.jobw@bl

## Estructura del Proyecto
```
moonlightbl/
├── backend/
│   ├── .env
│   ├── requirements.txt
│   └── server.py
├── frontend/
│   ├── .env
│   ├── package.json
│   ├── public/
│   └── src/
│       ├── components/
│       ├── lib/
│       └── pages/
└── README.md
```

## Características Principales

### Público
- Página de inicio con carrusel
- Catálogos por tipo (Series, Miniseries, Películas, Anime)
- Fichas de contenido detalladas
- Reproductor de video con múltiples servidores
- Búsqueda y filtros
- Páginas legales y de contacto

### Panel de Administración
- Dashboard con estadísticas
- CRUD completo de contenidos
- Gestión independiente de temporadas
- Gestión independiente de episodios con fuentes de video
- Configuración del carrusel
- Estadísticas y gráficos

## API Endpoints Principales

### Autenticación
- POST /api/auth/login

### Público
- GET /api/contents
- GET /api/contents/{slug}
- GET /api/carousel

### Admin (requiere autenticación)
- GET/POST/PUT/DELETE /api/admin/contents
- GET/POST/PUT/DELETE /api/admin/seasons
- GET/POST/PUT/DELETE /api/admin/episodes

## Licencia
Proyecto privado - Todos los derechos reservados

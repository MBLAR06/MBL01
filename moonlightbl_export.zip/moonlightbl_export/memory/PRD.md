# MoonlightBL - Product Requirements Document

## Información General
- **Nombre**: MoonlightBL
- **Tipo**: Plataforma de catálogo de series BL, miniseries, películas y anime LGBT
- **Stack**: FastAPI (Python) + React + MongoDB
- **Fecha de inicio**: 15 Enero 2026
- **Última actualización**: 15 Enero 2026

## User Personas
1. **Visitante**: Fan de contenido BL/LGBT que busca series, películas y anime para ver
2. **Administrador**: Gestor del catálogo con acceso completo al panel administrativo

## Requisitos Core (Estáticos)
- [x] Catálogo de contenidos por tipo (Series, Miniseries, Películas, Anime)
- [x] Sistema de temporadas y episodios para series
- [x] Reproductor de video embebido con múltiples servidores externos
- [x] Panel administrativo protegido con autenticación
- [x] Carrusel configurable en página de inicio
- [x] Sistema de búsqueda y filtros
- [x] Estadísticas de vistas
- [x] Gestión independiente de Temporadas y Episodios (COMPLETADO)
- [ ] Integración con TMDB/IMDb (preparado, pendiente API key)
- [ ] Envío de emails desde formulario de contacto (MOCKED - guarda en DB)

## Lo Implementado (15 Enero 2026)

### Backend (FastAPI)
- ✅ API REST completa en `/api/`
- ✅ Autenticación JWT con credenciales fijas (ADMINBL)
- ✅ CRUD completo de contenidos, temporadas y episodios
- ✅ Sistema de estados (pending/published)
- ✅ Estadísticas de vistas por período
- ✅ Carrusel configurable
- ✅ Búsqueda y filtros
- ✅ Audit logs
- ✅ **NUEVO**: Endpoints independientes para temporadas y episodios
  - GET /api/admin/all-seasons
  - GET /api/admin/all-episodes
  - GET /api/admin/seasons/{id}
  - GET /api/admin/episodes/{id}
  - PUT /api/admin/seasons/{id}/update
  - PUT /api/admin/episodes/{id}

### Frontend Público
- ✅ Página de inicio con hero carousel y filas de contenido
- ✅ Catálogos por tipo con filtros (género, año, país)
- ✅ Fichas de contenido con detalles completos
- ✅ Página de episodio con reproductor embebido y selección de servidor
- ✅ Navegación responsive (desktop y móvil)
- ✅ Tema nocturno elegante (azul oscuro/violeta)
- ✅ Búsqueda global
- ✅ Páginas legales (Aviso Legal, Privacidad)
- ✅ Formulario de contacto (guarda en DB)

### Panel Administrativo
- ✅ Login protegido con JWT
- ✅ Dashboard con estadísticas en tiempo real
- ✅ CRUD de contenidos (crear, editar, eliminar)
- ✅ Gestión de temporadas por serie
- ✅ Gestión de episodios con múltiples servidores
- ✅ Configuración del carrusel
- ✅ Estadísticas y gráficas de vistas
- ✅ **NUEVO**: Sección independiente de Temporadas (/admin/temporadas)
- ✅ **NUEVO**: Sección independiente de Episodios (/admin/episodios)
- ✅ **NUEVO**: Formulario de edición de temporada con:
  - Número, título, slug (URL personalizable)
  - URL personalizada
  - Portada y backdrop editables
  - Año, sinopsis, fecha de estreno
  - TMDB ID, IMDb ID
  - Estado (pendiente/publicada)
- ✅ **NUEVO**: Formulario de edición de episodio con:
  - Número, título, slug (URL personalizable)
  - URL personalizada
  - Portada y miniatura editables
  - Duración, sinopsis, fecha de emisión
  - TMDB ID, IMDb ID
  - Estado (pendiente/publicado)
  - **Sección de Fuentes de Video**: nombre del servidor, tipo (iframe/embed/mp4/shortcode), URL/código, calidad, subtítulos, audio, estado activo/inactivo

## Backlog Priorizado

### P0 (Crítico) - COMPLETADO
- [x] Gestión independiente de Temporadas y Episodios con URLs personalizables
- [x] Sección de fuentes de video con calidad, tipo, subtítulos, audio

### P1 (Alta prioridad) - Pendiente de API Keys
- [ ] Integración TMDB para importación automática de datos (requiere API key del usuario)
- [ ] Integración Resend para envío de emails desde contacto (requiere API key del usuario)

### P2 (Media prioridad)
- [ ] Backup automático de base de datos
- [ ] SEO: meta tags dinámicos y sitemap
- [ ] Rate limiting en login (captcha después de 5 intentos)
- [ ] Galería de imágenes en fichas de contenido
- [ ] Sistema de comentarios/reviews

### P3 (Baja prioridad)
- [ ] Sistema de usuarios visitantes con favoritos
- [ ] Notificaciones de nuevos episodios
- [ ] Modo offline/PWA
- [ ] Soporte para múltiples idiomas (i18n)

## Credenciales
- **Usuario Admin**: ADMINBL
- **Contraseña Admin**: 86@$#&bihutrfcñpKGe.jobw@bl

## URLs del Panel Administrativo
- `/admin/login` - Login de administrador
- `/admin` - Dashboard
- `/admin/contenidos` - Gestión de contenidos
- `/admin/contenidos/nuevo` - Crear contenido
- `/admin/contenidos/:id` - Editar contenido
- `/admin/contenidos/:id/temporadas` - Temporadas de un contenido
- `/admin/temporadas` - **NUEVO** Lista de todas las temporadas
- `/admin/temporadas/:id/editar` - **NUEVO** Editar temporada
- `/admin/temporadas/:seasonId/episodios` - Episodios de una temporada
- `/admin/episodios` - **NUEVO** Lista de todos los episodios
- `/admin/episodios/:id/editar` - **NUEVO** Editar episodio
- `/admin/carrusel` - Configuración del carrusel
- `/admin/estadisticas` - Estadísticas

## URLs Públicas
- `/` - Página de inicio
- `/series` - Catálogo de series
- `/miniseries` - Catálogo de miniseries
- `/peliculas` - Catálogo de películas
- `/anime` - Catálogo de anime
- `/buscar` - Búsqueda
- `/:type/:slug` - Ficha de contenido
- `/:type/:slug/temporada/:seasonSlug` - Temporada
- `/:type/:slug/temporada/:seasonSlug/episodio/:episodeSlug` - Episodio
- `/aviso-legal` - Aviso legal
- `/privacidad` - Política de privacidad
- `/contacto` - Formulario de contacto

## Notas Técnicas
- Todos los videos se reproducen mediante enlaces externos (ok.ru, streamtape, etc.)
- No se alojan archivos de video en el servidor
- Las imágenes se referencian por URL externa
- Los episodios y temporadas tienen URLs personalizables (slugs editables)
- Las temporadas se vinculan a contenidos por content_id
- Los episodios se vinculan a temporadas por season_id
- Las fuentes de video usan el modelo ServerLink con campos: name, url, embed_type (iframe/embed/mp4/shortcode), quality, subtitles, audio, is_active, order

## Modelo de Datos

### ServerLink
```python
{
    "name": str,           # Nombre del servidor (ok.ru, streamtape, etc.)
    "url": str,            # URL completa o código embed
    "embed_type": str,     # iframe | embed | mp4 | shortcode
    "is_active": bool,     # Si está activo
    "subtitles": str,      # Idioma de subtítulos
    "audio": str,          # Idioma de audio
    "quality": str,        # 480p, 720p, 1080p, etc.
    "order": int           # Orden de preferencia
}
```

### Season
```python
{
    "id": str,
    "content_id": str,
    "number": int,
    "title": str,
    "slug": str,
    "custom_url": str,
    "poster": str,
    "backdrop": str,
    "year": int,
    "synopsis": str,
    "tmdb_id": str,
    "imdb_id": str,
    "air_date": str,
    "status": str,          # pending | published
    "episode_count": int
}
```

### Episode
```python
{
    "id": str,
    "season_id": str,
    "content_id": str,
    "number": int,
    "title": str,
    "slug": str,
    "custom_url": str,
    "synopsis": str,
    "duration": int,
    "poster": str,
    "thumbnail": str,
    "servers": List[ServerLink],
    "tmdb_id": str,
    "imdb_id": str,
    "air_date": str,
    "status": str,          # pending | published
    "views": int
}
```

## Testing Status
- ✅ Backend: 18/18 tests pasados (100%)
- ✅ Frontend: Todos los componentes UI funcionando
- ✅ Test files: `/app/tests/test_admin_seasons_episodes.py`
- ✅ Test reports: `/app/test_reports/iteration_3.json`
